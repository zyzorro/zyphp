#!/bin/bash

export LD_LIBRARY_PATH=/usr/local/panda/libs
/usr/local/panda/panda
